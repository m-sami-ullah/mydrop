<?php

namespace App\Http\Controllers\api\Auth;

use Tymon\JWTAuth\Exceptions\TokenBlacklistedException;
use App\Http\Controllers\ApiController;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Helper\Functions;
use App\Notifications\LoginEmailCode;

use App\Services\SellerService;
use App\Models\Seller;
use Illuminate\Support\Facades\Hash;
use Notification;
use Mail;
use URL;
use Validator;
use JWTAuth;
use Illuminate\Auth\Events\Failed;
use Illuminate\Auth\Events\Login;
class LoginController extends ApiController
{
    use AuthenticatesUsers;
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
    protected $service;
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct(SellerService $service)
    {
        $this->service = $service;
        // $this->middleware('auth:api', ['except' => ['login']]);
    }

     
    public function social_login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'name' => 'required',
            // 'url' => 'required|url',
            'profileid' => 'required',
            'social' => 'required',
            ]);
            
        if ($validator->fails()) 
        {
            $this->incrementLoginAttempts($request);
            return $this->error($validator->errors()->first(),422);
        }

        try {

            if ($seller = $this->ValidEmail($request)) 
            {
                $data['user'] = $seller;

            }else
            {
                $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    // 'url' => 'required|url',
                    'profileid' => 'required|unique:sellers,profile',
                    'social' => 'required',
                    ]);
                    
                if ($validator->fails()) 
                {
                    $this->incrementLoginAttempts($request);
                    return $this->error($validator->errors()->first(),422);
                }

                $social_type = $request->social == 'facebook' ? 'facebook':'google';

                $seller_data = [
                    'name' => $request->name,
                    'email' => $request->email,
                    'profile'=> $request->profileid,
                    'activated'=>1,
                    'email_verified_at'=>date("Y-m-d H:i:s"),
                    'social_id'=> $request->profileid,
                    'social_type'=> $social_type,
                    'password' => Hash::make(sha1(mt_rand(999,99999)))
                ];

                if ($request->has('url')) 
                {
                    $disk = \Storage::disk('local');

                    $fileContents = file_get_contents(urldecode($request->url));

                    $filename = $request->profileid .'.jpg';
                    $file = '/temp/' . $filename;
                    $disk->put($file,$fileContents);
                    
                    $filepath = 'avatar' . '/' .$filename;

                    $disk->move($file,$filepath);

                    $seller_data['avatar'] = $filename;
                }

                $seller = Seller::create($seller_data);
                $data['user'] = $seller   = $this->ValidEmail($request);
            }


            $token= JWTAuth::fromUser($seller);

            $data['access_token'] = $token;
            $data['token_type'] = 'bearer';
            $data['expires_in'] = auth('api')->factory()->getTTL() * 60;

            $data['user'] = $this->service->resource($seller);
            return $this->success($data,'User login successfully');


        } catch (Exception $e) 
        {
            return $this->error('Something goes wrong',401);;
        }
    } 
     
    
    protected function credentials(Request $request)
    {
        return ['email'=>$request->{$this->username()}, 'password'=>$request->password, 'activated'=>'1', 'blocked'=>'0'];
    }

    public function forgot_email_password(Request $request)
    {
        
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        } 

        $validator = Validator::make($request->all(), [
            $this->username() => 'required|email',
        ]);

         if ($validator->fails()) 
        {
            $this->incrementLoginAttempts($request);
            return $this->error($validator->errors(),422);
        } 

        if ($seller = $this->ValidEmail($request)) 
        {
            if ($seller->blocked==1) 
            {
                $message = 'Email '.$request->email . ' is blocked by the administrator';
                return $this->error($message,401);
            }elseif ($seller->activated==0 || $seller->activated==1) 
            {
                $code = $this->code();
                $this->updateCode($seller,$code);
                $message = 'We have send you a code in your email " '.$seller->email . ' ". Please verify.';

                Notification::send($seller, new LoginEmailCode($code));
 
                $this->incrementLoginAttempts($request);

                return $this->success(null,$message);

            }

        }else
        {
            $code = $this->code();
            $seller = $this->created($request,$code);
            $message = 'We have send you a code in you email " '.$request->email . ' ". Please verify.';

            Notification::send($seller, new LoginEmailCode($code));
            
 
            $this->incrementLoginAttempts($request);

            return $this->success(null,$message);
        }

        return $this->sendFailedLoginResponse($request);
    }
    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Http\JsonResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function login(Request $request)
    {
 
            if (method_exists($this, 'hasTooManyLoginAttempts') &&
                $this->hasTooManyLoginAttempts($request)) {
                $this->fireLockoutEvent($request);

                return $this->sendLockoutResponse($request);
            }
 
        // dd($request->all());
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string',//|min:6
        ]);

        if ($validator->fails()) 
        {

            $this->incrementLoginAttempts($request);
            return $this->error($validator->errors(),422);
        }

        if (! $token = auth('api')->attempt($this->credentials($request))) 
        {
            event(new Failed('api','',$this->credentials($request)));
            $this->incrementLoginAttempts($request);
            return $this->error('Wrong Email or Password',401);
        }

        event(new Login('api',auth('api')->user(),0));

        return $this->createNewToken($token);
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Http\JsonResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function before_login(Request $request)
    {
        
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }
        

        // dd('--');
        $validator = Validator::make($request->all(), [
            $this->username() => 'required|email',
        ]);

         if ($validator->fails()) 
        {
            $this->incrementLoginAttempts($request);
            return $this->error($validator->errors(),422);
        }

        // $this->validateBeforeLogin($request);
        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        
        // if (method_exists($this, 'hasTooManyLoginAttempts') &&
        //     $this->hasTooManyLoginAttempts($request)) {
        //     $this->fireLockoutEvent($request);

        //     return $this->sendLockoutResponse($request);
        // }

        if ($seller = $this->ValidEmail($request)) 
        {
            if ($seller->blocked==1) 
            {
                $message = 'Email '.$request->email . ' is blocked by the OUI administrator';
                return $this->error($message,401);
            }elseif ($seller->activated==0) 
            {

               
                $code = $this->code();
                $this->updateCode($seller,$code);
                $message = 'We have send you a code in your email " '.$request->email . ' ". Please verify.';

                Notification::send($seller, new LoginEmailCode($code));
 
                $this->incrementLoginAttempts($request);

                return $this->success(null,$message);
                // return redirect()->route('seller.auth.emailcode')->withInput(request()->all());

            }elseif ($seller->activated==1) 
            {
                $record = $this->service->resource($seller);
 
                $this->clearLoginAttempts($request);
                return $this->success($record,'Need your passwowrd');
                // return redirect()->route('seller.auth.emailpassowrd')->withInput(request()->all());
            }
        }else
        {
            $code = $this->code();
            $seller = $this->created($request,$code);
            $message = 'We have send you a code in you email " '.$request->email . ' ". Please verify.';

            Notification::send($seller, new LoginEmailCode($code));
            
 
            $this->incrementLoginAttempts($request);

            return $this->success(null,$message);
            // return redirect()->route('seller.auth.emailcode')->withInput(request()->all())->with(['seller' => $seller->only('id','name','email')]);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        // $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }

    


    protected function ValidEmail(Request $request)
    {
        return Seller::where('email',$request->email)->first(); 
    }

     

    public function verifycode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:sellers,email',
            'code' => 'required|digits:4',//|min:6
        ]);
        
        if ($validator->fails()) 
        {
            $this->incrementLoginAttempts($request);
            return $this->error($validator->errors(),422);
        }

        $email = $request->email;
        $code = $request->code;

        $seller = $this->ValidEmail($request);
        if ($seller && $seller->code===$code) 
        {
            $message = 'Please set your password to access your account next time.';
            // $request->merge(['code'=>$code]);
            $record = $this->service->resource($seller);
            return $this->success($record,$message);
            // return redirect()->route('seller.auth.setemailpassword')->withInput(request()->all())->with(['code' => $seller->code]);
        }else
        {
            $this->incrementLoginAttempts($request);
            $error = 'Your code is invalid. Please try again!';
            return $this->error($error,422);
        }
       
    }
    // public function showEmailPasswordForm(Request $request)
    // {
    //     $email = $request->email;
    //     $code = $request->code;
    //     return view('seller.auth.set-password',compact('email','code'));
    // }
    public function setemailpassword(Request $request)
    {
        // dd($seller = session('seller'));
        // dd('seller---');
        $request->validate([
            'email' => 'required|string|email|max:255|exists:sellers,email',
            'password' => 'required|string|min:8',
            'code' => 'required|digits:4',
        ]);
        
        
        $seller = Seller::where('email',$request->email)->where('code',$request->code)->first();
        // dd($seller);
        if ($seller) 
        {
            
            $uniqid = $this->findUniqeID();
            $seller->update(['password'=>Hash::make($request->password),'code'=>null,'activated'=>1,'email_verified_at'=>date("Y-m-d H:i:s"),'profile'=>$uniqid]);


            // $token = JWTAuth::fromUser($finduser);
            return $this->login($request);
            // return $this->success($token,'Login successfully');
        }else{

            $this->incrementLoginAttempts($request);
            return $this->error('Your code is invalid',401);
        }

    }
    protected function findUniqeID()
    {
        $uniqid = uniqid();
        $isUnique = Seller::where('profile',$uniqid)->count(); 
        $i = 0;
        while ($isUnique && $i<10)  
        {
            $uniqid = uniqid(); 
            $isUnique = Seller::where('profile',$uniqid)->count();
                
        }
        return $uniqid;

    }   
    public function updateCode($seller,$code)
    {
        return $seller->update(['code'=>$code]);
    }
    protected function created(Request $request,$code)
    {
        
        $getname = explode('@', $request->email);
        $name = array_key_exists(0, $getname) ? $getname[0] : '';
        return Seller::create(['email'=>$request->email,'code'=>$code,'name'=>$name,'password' => Hash::make(sha1(mt_rand(999,99999)))]);
    }
    public function code()
    {
        $code = mt_rand(1000,9999);
        $has_code = Seller::where('code',$code)->count();
        while ($has_code) 
        {
            $code = mt_rand(1000,9999);
            $has_code = Seller::where('code',$code)->count();
                   
        }
        return $code;
    }
    /**
     * Validate the user login request.
        
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function validateLogin(Request $request)
    {
        $request->validate([
            $this->username() => 'required|email',
            'password' => 'required|string',
        ]);
    }

    /**
     * Validate the user login request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    // protected function validateBeforeLogin(Request $request)
    // {
    //     $request->validate([
    //         $this->username() => 'required|email',
    //     ]);
    // }
    /**
     * Attempt to log the user into the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function attemptLogin(Request $request)
    {
        return $this->guard()->attempt(
            $this->credentials($request), $request->filled('remember')
        );
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    // protected function credentials(Request $request)
    // {
    //     return $request->only($this->username(), 'password');
    // }
    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username()
    {
        return 'email';
    }


    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('api');
    }

    public function refresh()
    {
        try {

            return $this->respondWithToken(auth()->guard('api')->refresh());
            
        }catch(TokenBlacklistedException $e) {
        
        return $this->error('Token has been blacklisted',403);
          
        } catch(Exception $e) 
        {
            return $this->error($e->getMessage(),403);//'An error while decoding token.'
 
        }
    }
    
    protected function respondWithToken($token)
    {
        return $this->success([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            // 'user' => auth('api')->user() 
        ]);
         
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */

    protected function createNewToken($token){
        return $this->success([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            // 'user' => auth('api')->user() 
        ]);
        // return response()->json();
    }
}
